# twp-pdf-view
A PDF viewer that allows translation through the extension TWP - Translate Web Pages
